﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace station
{
    public class StationDetails
    {

        

            public string[] arrA2 = { "Waterfront",
"Vancouver City Centre",
"Yaletown Roundhouse",
"Olympic Village",
"Broadway City Hall",
"King Edward",
"Oakridge 41st Avenue",
"Langara 49th Avenue",
"Marine Drive",
"Bridgeport",
"Aberdeen",
"Lansdowne",
"Richmond Brighouse"

            };

            public string[] arrA1 ={
                "Bridgeport",
                "Templeton",
                "Sea Island",
                "YVR"
            };


            public string[] arrA3 = {"Waterfront",
"Burrard",
"Granville",
"Stadium Chinatown",
"Main Street Science World",
"Commercial Broadway",
"Nanaimo",
"29th Avenue",
"Joyce Collingwood",
"Patterson",
"Metrotown",
"Royal Oak",
"Edmonds",
"22nd Street",
"New Westminster",
"Columbia",
"Sapperton",
"Braid",
"Lougheed Town Centre",
"Production Way University"};



            public string[] arrA4 = { "Columbia",
"Scott Road",
"Gateway",
"Surrey Central",
"King George"};

            public string[] arrA5 = { "VCC Clark",
"Commercial Broadway",
"Renfrew",
"Rupert",
"Gilmore",
"Brentwood Town Centre",
"Holdom",
"Sperling Burnaby Lake",
"Lake City Way",
"Production Way University",
"Lougheed Town Centre",
"Burquitlam",
"Moody Centre",
"Inlet Centre",
"Coquitlam Central",
"Lincoln",
"Lafarge Lake Douglas"};

        }
    }
 